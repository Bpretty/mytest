#!/bin/bash
cd ./bin
./server
